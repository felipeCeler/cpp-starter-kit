// Use double precision for better python integration.
// Need also define this in `binding.cc`(and all compilation units)
#define TINYOBJLOADER_USE_DOUBLE

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"
